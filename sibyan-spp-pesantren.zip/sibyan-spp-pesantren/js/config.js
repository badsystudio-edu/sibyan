/* ============================================================
 * KONFIGURASI — satu-satunya berkas yang perlu Anda isi.
 * Tempel URL Web App Google Apps Script (berakhiran /exec) di bawah.
 * ============================================================ */
const GAS_URL = 'ISI_DENGAN_URL_EXEC_ANDA';

const APP_CFG = {
  namaDefault: 'Pesantren Musholla Hidayatus Sibyan Bades',
  tz: 'Asia/Jakarta'
};
